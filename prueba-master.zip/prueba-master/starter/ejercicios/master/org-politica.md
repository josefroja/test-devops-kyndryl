# Política deseada de la organización (borrador del CIO)

| Tier | Ejemplos | Qué debe cumplirse en el pipeline |
|------|----------|-----------------------------------|
| tier0 | checkout, payments, ledger | Todos los gates **bloqueantes** con reglas estrictas, procedencia verificable, aprobación para producción |
| tier1 | catalog, search, identity | SAST + SCA + calidad bloqueantes con reglas estándar |
| tier2 | reporting, notifications | SAST + SCA bloqueantes con reglas moderadas |
| tier3 | herramientas internas | Mínimos comunes de seguridad |

Mínimos comunes a TODO tier: permisos mínimos, acciones fijadas por SHA, sin secretos en claro, sin inyección de contexto, sin `pull_request_target`,
`timeout-minutes`, sin gates ignorables (`|| true`, `continue-on-error`) y sin gates sin reglas.
Los workflows de `org-workflows/` son los de cinco squads: úsalos para validar tu política.
