#!/usr/bin/env bash
# Genera tráfico contra el servicio. Uso: tools/loadgen.sh <url-base> [segundos=60] [%-errores=0]
# Los errores son peticiones inválidas a /greet/ (HTTP 400) y cuentan en app_errors_total.
set -euo pipefail
base="${1:?url base, p.ej. http://localhost:8080}"; secs="${2:-60}"; errpct="${3:-0}"
end=$((SECONDS + secs)); n=0
while [ $SECONDS -lt $end ]; do
  if [ $((RANDOM % 100)) -lt "$errpct" ]; then curl -s -o /dev/null "$base/greet/bad%20name" || true
  else curl -s -o /dev/null "$base/greet/Ana" || true; fi
  n=$((n+1)); sleep 0.05
done
echo "enviadas: $n peticiones (errores ~${errpct}%)"
