package com.kyndryl.eval;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicLong;

/** Hello World (solo JDK) usado como workload de la prueba. No es lo que se evalúa. */
public class App {
    static final AtomicLong REQUESTS = new AtomicLong();
    static final AtomicLong ERRORS = new AtomicLong();

    public static HttpServer start(int port) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        String version = System.getenv().getOrDefault("APP_VERSION", "1.0.0");
        String env = System.getenv().getOrDefault("APP_ENV", "local");

        server.createContext("/", ex -> {
            if (!ex.getRequestURI().getPath().equals("/")) { json(ex, 404, "{\"error\":\"not found\"}"); return; }
            json(ex, 200, "{\"message\":\"Hello, World!\"}");
        });
        server.createContext("/health", ex -> json(ex, 200,
            "{\"status\":\"ok\",\"version\":\"" + version + "\",\"env\":\"" + env + "\"}"));
        server.createContext("/ready", ex -> json(ex, 200, "{\"ready\":true}"));
        server.createContext("/greet/", ex -> {
            String name = ex.getRequestURI().getPath().substring("/greet/".length());
            if (!name.matches("[A-Za-z0-9_-]{1,40}")) {
                json(ex, 400, "{\"error\":\"invalid name\"}");
                return;
            }
            json(ex, 200, "{\"message\":\"Hello, " + name + "!\"}");
        });
        server.createContext("/metrics", ex -> {
            byte[] body = ("# TYPE app_requests_total counter\napp_requests_total " + REQUESTS.get() + "\n"
                + "# TYPE app_errors_total counter\napp_errors_total " + ERRORS.get() + "\n")
                .getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().add("Content-Type", "text/plain; version=0.0.4");
            ex.sendResponseHeaders(200, body.length);
            ex.getResponseBody().write(body);
            ex.close();
        });
        server.start();
        return server;
    }

    private static void json(HttpExchange ex, int status, String body) throws IOException {
        REQUESTS.incrementAndGet();
        if (status >= 400) ERRORS.incrementAndGet();
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "application/json");
        ex.sendResponseHeaders(status, bytes.length);
        ex.getResponseBody().write(bytes);
        ex.close();
    }

    public static void main(String[] args) throws IOException {
        int port = Integer.parseInt(System.getenv().getOrDefault("PORT", "8080"));
        start(port);
        System.out.println("listening on :" + port);
    }
}
